# Deep Learning Lab Experiments

Lab experiments for a Deep Learning / Neural Networks course.

| # | Experiment | Dataset | Key Concept |
|---|------------|---------|--------------|
| 4 | [Multilayer Neural Network](experiment-4-multilayer-nn/multilayer_nn.py) | Iris | Multi-hidden-layer dense network, dropout |
| 5 | [Basic CNN](experiment-5-basic-cnn/basic_cnn.py) | MNIST | Convolutional layers built from scratch |
| 6 | [Transfer Learning in CNN](experiment-6-transfer-learning/transfer_learning_cnn.py) | CIFAR-10 | VGG16 feature extraction vs. training from scratch |

> Experiment 3 is not included yet — add it as `experiment-3-<name>/` following the same structure once you have that file.

## Setup

```bash
pip install -r requirements.txt
```

## Running an experiment

```bash
python experiment-4-multilayer-nn/multilayer_nn.py
```

Each script loads its dataset via Keras/scikit-learn built-in loaders, so no manual dataset download is required.
